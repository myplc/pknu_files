const Home = () => {
    return (
        <>
            <h1> Home 페이지 시즌2 입니다. </h1>
            <h2>React ex07 ~ ex 를 준비하였습니다.</h2>
        </>
    )
}
export default Home