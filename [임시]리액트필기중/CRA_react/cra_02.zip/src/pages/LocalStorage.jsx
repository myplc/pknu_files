const LocalStorage = () => <h1>로컬스토리지 작성중...</h1>


export default LocalStorage