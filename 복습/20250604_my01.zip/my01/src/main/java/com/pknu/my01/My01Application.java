package com.pknu.my01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class My01Application {

	public static void main(String[] args) {
		SpringApplication.run(My01Application.class, args);
	}

}
