const list = ['HTML', 'CSS', 'JAVASCRIPT', 'JAVA', 'PYTHON', 'Oracle', 'MySQL', 'Nodejs']


export default list