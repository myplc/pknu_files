package com.pknu.my01.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class My01Controller {
    @GetMapping("/")
    public String mainPage(Model model) {
        List<String> pageNames = List.of("model", "increase", "ex3", "ex4", "ex5", "ex6");
        model.addAttribute("pages", pageNames);
        return "index"; // templates/index.html
    }

    @GetMapping("/model")
    public String ex01(Model model) {
        model.addAttribute("hello", "만나서 아주 반갑습니다. 스프링부트 시작합니다.");
        model.addAttribute("name", "홍길동");
        model.addAttribute("age", 22);
        return "ex01"; // templates/ex01.html
    }

    @GetMapping("/increase")
    public String ex02(Model model) {
        List<Integer> sampleNumbers = List.of(11, 22, 33, 44, 55, 66, 77);
        model.addAttribute("numbers", sampleNumbers);
        return "ex02"; // templates/ex02.html
    }
}
